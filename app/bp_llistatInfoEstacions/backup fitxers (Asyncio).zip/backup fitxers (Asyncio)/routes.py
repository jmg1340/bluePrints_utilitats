from flask import render_template, request, session, url_for
from . import llistatEstacions
from app import socketioApp
from flask_socketio import emit
from .clHost import Host
import ipaddress
import asyncio
import subprocess




@llistatEstacions.route('/llistatEstacions', methods=['GET'])
def fllistatEstacions():
	if "username" in session:
		return render_template( 'llistat.html', titol="Llistat informació estacions plataforma" )
	else:
		return "Accés prohibit."



@socketioApp.on('arranca_proces_info_estacions')
async def arranca_proces( strAdreçaXarxa ):
    print( "estic a 'ejecutarProcessos'")
    """
    Función principal que orquesta la ejecución concurrente.
    """
    # Lista de IPs a comprobar. Puedes cambiarla por las que quieras.
    rangIPs = ipaddress.ip_network( strAdreçaXarxa )
    hostsXarxa = rangIPs.hosts()    # hostsXarxa es un objecte "generator"
    ips_a_comprobar = [i for i in hostsXarxa] # conversio de objecte "generator" a objecte "llista"


    print(f"Comprovant {len(ips_a_comprobar)} IPs...")
    
    # Creamos una lista de tareas, una para cada IP, usando una comprensión de listas.
    tareas = [asyncio.create_task(recullInformacio(ip)) for ip in ips_a_comprobar]


    # Usamos asyncio.as_completed para iterar sobre las tareas a medida que terminan
    for tarea in asyncio.as_completed(tareas):
        # Esperamos el resultado de la tarea que acaba de terminar
        obj = await tarea
        
        if obj["faPing"]:
            if obj["nomHost"].startswith("Error"):
                # IPs que fan ping pero que dona error al recuperar el hostName
                socketioApp.emit('recepcioDades', "")
                print(f"ip {obj['target']:<13} [🟢 UP]", f"Nom: {obj['nomHost']}")
            else:
                # IPs que responen a pings i recuperen hostName de la estació
                arr = [
                    obj['target'],  # ip
                    obj['nomHost'], # host name
                    obj['usuari'] or "",    # usuari 
                    obj['model'] or "",   # model del Host
                    # "NS Host" or "", 
                    obj['ns_monitor'] or "",    #NS Monitor
                    obj['mac'], 
                    obj['speed'], 
                    obj['paquets'], 
                    obj['switch'] or "", 
                    obj['port']
                ]

                socketioApp.emit('recepcioDades', arr)
                print(f"ip {obj['target']:<13} [🟢 UP]", f"HOST: {obj['nomHost']:<10} USER: {obj['usuari']:<8} MODEL: {obj['model']} NS_monitor: {obj['ns_monitor']} MAC: {obj['mac']} PAQUETS: {obj['paquets']} SPEED: {obj['speed']} SWITCH: {obj['switch']} PORT: {obj['port']}")
        else:
            # IPs que no responen a pings
            socketioApp.emit('recepcioDades', "")
            print(f"ip {obj['target']:<13} [🔴 DOWN]")
 



async def recullInformacio( ip ):
    info = {
        "target": ip,
        "faPing": None,
        "nomHost": None,
        "usuari":  None,
        "mac": None,
        "paquets": None,
        "speed": None,
        "switch": None,
        "port": None,
        "marca": None,
        "model": None,
        "num_serie": None,
        "ns_monitor": None
    }
    
    
    objHost = Host( ip )
    info["faPing"] = await objHost.comprovarPing()

    errorHost = False
    if info["faPing"]:
        info["nomHost"] = await objHost.getNomHost()
        if not info["nomHost"].startswith("Error"):
            info["usuari"] = await objHost.getUsuari()
            
            mac_paquets = await objHost.getIpMac()
            info["mac"] = mac_paquets[0]
            info["paquets"] = mac_paquets[1]

            info["speed"] = await objHost.getSpeed()

            connectatA = await objHost.getConnectatA()
            info["switch"] = connectatA[0]
            info["port"] = connectatA[2]

            getInfoPc = await objHost.getInfoPc()
            info["marca"] = getInfoPc[0]
            info["model"] = getInfoPc[1]
            info["num_serie"] = getInfoPc[2]

            info["ns_monitor"] = await objHost.getInfoMonitor()

    return info


